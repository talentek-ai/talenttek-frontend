import EmployerLayout from "@/components/layouts/EmployerLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Briefcase, Users, Calendar, CheckCircle, TrendingUp } from "lucide-react";

const EmployerOverview = () => {
  const stats = [
    {
      title: "Active Jobs",
      value: "8",
      description: "Open positions",
      icon: Briefcase,
      gradient: "from-blue-500 to-cyan-500",
    },
    {
      title: "Applications",
      value: "156",
      description: "Total received",
      icon: Users,
      gradient: "from-purple-500 to-pink-500",
    },
    {
      title: "Interviews",
      value: "24",
      description: "This week",
      icon: Calendar,
      gradient: "from-orange-500 to-red-500",
    },
    {
      title: "Hired",
      value: "12",
      description: "This month",
      icon: CheckCircle,
      gradient: "from-green-500 to-emerald-500",
    },
    {
      title: "Time to Hire",
      value: "18 days",
      description: "Average",
      icon: TrendingUp,
      gradient: "from-indigo-500 to-blue-500",
    },
  ];

  return (
    <EmployerLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Dashboard Overview</h1>
          <p className="text-muted-foreground mt-1">Monitor your recruitment metrics</p>
        </div>
        
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.title} className="overflow-hidden hover-scale">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      {stat.title}
                    </CardTitle>
                    <div className={`p-2 rounded-lg bg-gradient-to-br ${stat.gradient}`}>
                      <Icon className="h-4 w-4 text-white" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-1">{stat.value}</div>
                  <p className="text-xs text-muted-foreground">{stat.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </EmployerLayout>
  );
};

export default EmployerOverview;
