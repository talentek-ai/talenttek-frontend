import EmployerLayout from "@/components/layouts/EmployerLayout";

const EmployerInterviewers = () => {
  return (
    <EmployerLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Interviewers</h1>
        <p className="text-muted-foreground">Manage your interview team</p>
      </div>
    </EmployerLayout>
  );
};

export default EmployerInterviewers;
