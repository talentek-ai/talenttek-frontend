import EmployerLayout from "@/components/layouts/EmployerLayout";

const EmployerInterviews = () => {
  return (
    <EmployerLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Interviews</h1>
        <p className="text-muted-foreground">Schedule and manage interviews</p>
      </div>
    </EmployerLayout>
  );
};

export default EmployerInterviews;
