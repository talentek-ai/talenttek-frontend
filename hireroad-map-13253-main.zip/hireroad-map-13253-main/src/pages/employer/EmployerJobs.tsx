import EmployerLayout from "@/components/layouts/EmployerLayout";

const EmployerJobs = () => {
  return (
    <EmployerLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Job Listings</h1>
        <p className="text-muted-foreground">Manage your job postings</p>
      </div>
    </EmployerLayout>
  );
};

export default EmployerJobs;
