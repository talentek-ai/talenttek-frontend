import EmployerLayout from "@/components/layouts/EmployerLayout";

const EmployerTickets = () => {
  return (
    <EmployerLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Support Tickets</h1>
        <p className="text-muted-foreground">Manage support requests</p>
      </div>
    </EmployerLayout>
  );
};

export default EmployerTickets;
