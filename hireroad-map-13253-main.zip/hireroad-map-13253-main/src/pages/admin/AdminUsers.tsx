import AdminLayout from "@/components/layouts/AdminLayout";

const AdminUsers = () => {
  return (
    <AdminLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">User Management</h1>
        <p className="text-muted-foreground">Manage all platform users</p>
      </div>
    </AdminLayout>
  );
};

export default AdminUsers;
