import { useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Briefcase, Calendar, Shield } from "lucide-react";

const mockStats = {
  totalUsers: 1248,
  roleDistribution: [
    { role: "Admin", count: 8, percentage: 0.6 },
    { role: "Employer", count: 156, percentage: 12.5 },
    { role: "Talent", count: 982, percentage: 78.7 },
    { role: "Interviewer", count: 102, percentage: 8.2 },
  ],
  totalJobs: 342,
  totalInterviews: 567,
  totalTickets: 89,
};

export default function SuperAdminDashboard() {
  const [activeSection, setActiveSection] = useState("overview");

  const renderContent = () => {
    switch (activeSection) {
      case "overview":
        return (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">Dashboard Overview</h2>

            {/* Stats Grid */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{mockStats.totalUsers}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Total Jobs</CardTitle>
                  <Briefcase className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{mockStats.totalJobs}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Interviews</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{mockStats.totalInterviews}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Open Tickets</CardTitle>
                  <Shield className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{mockStats.totalTickets}</div>
                </CardContent>
              </Card>
            </div>

            {/* Role Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Role Distribution Per User</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockStats.roleDistribution.map((item) => (
                    <div key={item.role} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">{item.role}</span>
                        <span className="text-muted-foreground">
                          {item.count} ({item.percentage}%)
                        </span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div
                          className="h-2 rounded-full bg-gradient-to-r from-primary to-secondary transition-all"
                          style={{ width: `${item.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case "users":
        return (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">Users Management</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-muted-foreground">User management interface coming soon...</p>
              </CardContent>
            </Card>
          </div>
        );

      case "interviews":
        return (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">Interviews</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-muted-foreground">Interview management interface coming soon...</p>
              </CardContent>
            </Card>
          </div>
        );

      case "tickets":
        return (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">Support Tickets</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-muted-foreground">Ticket management interface coming soon...</p>
              </CardContent>
            </Card>
          </div>
        );

      case "jobs":
        return (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">Jobs Management</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-muted-foreground">Jobs management interface coming soon...</p>
              </CardContent>
            </Card>
          </div>
        );

      case "pricing":
        return (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">Pricing Management</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-muted-foreground">Pricing configuration interface coming soon...</p>
              </CardContent>
            </Card>
          </div>
        );

      case "sectors":
        return (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">Sector of Work</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-muted-foreground">Sector management interface coming soon...</p>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <DashboardLayout activeSection={activeSection} onSectionChange={setActiveSection}>
      {renderContent()}
    </DashboardLayout>
  );
}
