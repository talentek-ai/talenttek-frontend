import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/components/ui/password-input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

const TalentSignup = () => {
  const [step, setStep] = useState(1);
  const navigate = useNavigate();
  const { login } = useAuth();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    fullName: "",
    location: "",
    experienceLevel: "",
    skills: "",
    bio: "",
  });

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    login({
      id: '1',
      email: formData.email,
      name: formData.fullName,
      role: 'talent'
    });
    
    toast({
      title: "Account created successfully!",
      description: "Welcome to TalentsHub",
    });
    
    navigate('/talent/overview');
  };

  return (
    <div className="min-h-screen bg-gradient-hero">
      <Navbar />
      
      <div className="container mx-auto px-4 pt-32 pb-20">
        <div className="max-w-4xl mx-auto grid md:grid-cols-[1fr,300px] gap-8">
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle className="text-2xl">
                {step === 1 && "Account Setup"}
                {step === 2 && "Profile Information"}
                {step === 3 && "Upload & Confirm"}
              </CardTitle>
              <CardDescription>Step {step} of 3</CardDescription>
            </CardHeader>
            <CardContent>
              {step === 1 && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      value={formData.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <PasswordInput 
                      id="password" 
                      value={formData.password}
                      onChange={(e) => handleChange('password', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <PasswordInput 
                      id="confirmPassword" 
                      value={formData.confirmPassword}
                      onChange={(e) => handleChange('confirmPassword', e.target.value)}
                      required
                    />
                  </div>
                  <Button onClick={() => setStep(2)} className="w-full bg-gradient-primary hover:opacity-90">
                    Continue
                  </Button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input 
                      id="fullName" 
                      value={formData.fullName}
                      onChange={(e) => handleChange('fullName', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input 
                      id="location" 
                      value={formData.location}
                      onChange={(e) => handleChange('location', e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="experience">Experience Level</Label>
                    <Select onValueChange={(value) => handleChange('experienceLevel', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="junior">Junior</SelectItem>
                        <SelectItem value="mid">Mid</SelectItem>
                        <SelectItem value="senior">Senior</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="skills">Skills (comma separated)</Label>
                    <Input 
                      id="skills" 
                      placeholder="React, TypeScript, Node.js"
                      value={formData.skills}
                      onChange={(e) => handleChange('skills', e.target.value)}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={() => setStep(1)} variant="outline" className="w-full">
                      Back
                    </Button>
                    <Button onClick={() => setStep(3)} className="w-full bg-gradient-primary hover:opacity-90">
                      Next
                    </Button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="picture">Upload Profile Picture</Label>
                    <Input id="picture" type="file" accept="image/*" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="resume">Upload Resume (PDF)</Label>
                    <Input id="resume" type="file" accept=".pdf" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bio">Short Bio (Optional)</Label>
                    <Textarea 
                      id="bio" 
                      placeholder="Tell us about yourself..."
                      value={formData.bio}
                      onChange={(e) => handleChange('bio', e.target.value)}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={() => setStep(2)} variant="outline" className="w-full">
                      Back
                    </Button>
                    <Button onClick={handleSubmit} className="w-full bg-gradient-primary hover:opacity-90">
                      Create Talent Account
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="space-y-4">
            <div className="bg-card rounded-lg p-6 shadow-card">
              <h3 className="font-semibold mb-3">Looking for opportunities?</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Build your professional profile and connect with leading companies.
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <span className="text-primary">✓</span>
                  <span>Build your profile</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">✓</span>
                  <span>Get matched with dream jobs</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">✓</span>
                  <span>Apply with one click</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">✓</span>
                  <span>Track your applications</span>
                </li>
              </ul>
            </div>
            <p className="text-center text-sm text-muted-foreground">
              Already have an account?{" "}
              <Link to="/login" className="text-primary hover:underline font-medium">
                Sign In
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TalentSignup;
