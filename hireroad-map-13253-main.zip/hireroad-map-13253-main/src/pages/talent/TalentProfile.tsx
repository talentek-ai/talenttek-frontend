import TalentLayout from "@/components/layouts/TalentLayout";

const TalentProfile = () => {
  return (
    <TalentLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">My Profile</h1>
        <p className="text-muted-foreground">Manage your professional profile</p>
      </div>
    </TalentLayout>
  );
};

export default TalentProfile;
