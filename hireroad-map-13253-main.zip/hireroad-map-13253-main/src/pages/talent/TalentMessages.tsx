import TalentLayout from "@/components/layouts/TalentLayout";

const TalentMessages = () => {
  return (
    <TalentLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Messages</h1>
        <p className="text-muted-foreground">Connect with employers</p>
      </div>
    </TalentLayout>
  );
};

export default TalentMessages;
