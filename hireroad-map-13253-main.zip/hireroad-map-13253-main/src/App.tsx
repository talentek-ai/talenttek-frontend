import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import Home from "./pages/Home";
import ForEmployers from "./pages/ForEmployers";
import ForTalents from "./pages/ForTalents";
import Pricing from "./pages/Pricing";
import Login from "./pages/Login";
import GetStarted from "./pages/GetStarted";
import TalentSignup from "./pages/signup/TalentSignup";
import EmployerSignup from "./pages/signup/EmployerSignup";
import TalentOverview from "./pages/talent/TalentOverview";
import TalentJobs from "./pages/talent/TalentJobs";
import TalentApplications from "./pages/talent/TalentApplications";
import TalentProfile from "./pages/talent/TalentProfile";
import TalentMessages from "./pages/talent/TalentMessages";
import EmployerOverview from "./pages/employer/EmployerOverview";
import EmployerJobs from "./pages/employer/EmployerJobs";
import EmployerInterviewers from "./pages/employer/EmployerInterviewers";
import EmployerInterviews from "./pages/employer/EmployerInterviews";
import EmployerTickets from "./pages/employer/EmployerTickets";
import AdminOverview from "./pages/admin/AdminOverview";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminTickets from "./pages/admin/AdminTickets";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/for-employers" element={<ForEmployers />} />
            <Route path="/for-talents" element={<ForTalents />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/get-started" element={<GetStarted />} />
            <Route path="/signup/talent" element={<TalentSignup />} />
            <Route path="/signup/employer" element={<EmployerSignup />} />
            
            {/* Talent Routes */}
            <Route path="/talent/overview" element={<TalentOverview />} />
            <Route path="/talent/jobs" element={<TalentJobs />} />
            <Route path="/talent/applications" element={<TalentApplications />} />
            <Route path="/talent/profile" element={<TalentProfile />} />
            <Route path="/talent/messages" element={<TalentMessages />} />
            
            {/* Employer Routes */}
            <Route path="/employer/overview" element={<EmployerOverview />} />
            <Route path="/employer/jobs" element={<EmployerJobs />} />
            <Route path="/employer/interviewers" element={<EmployerInterviewers />} />
            <Route path="/employer/interviews" element={<EmployerInterviews />} />
            <Route path="/employer/tickets" element={<EmployerTickets />} />
            
            {/* Admin Routes */}
            <Route path="/admin/overview" element={<AdminOverview />} />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route path="/admin/tickets" element={<AdminTickets />} />
            
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
