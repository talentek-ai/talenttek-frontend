import { Link } from "react-router-dom";

const Footer = () => {
  const footerSections = [
    {
      title: "Platform",
      links: [
        { name: "For Employers", path: "/for-employers" },
        { name: "For Talents", path: "/for-talents" },
        { name: "Pricing", path: "/pricing" },
        { name: "How It Works", path: "/" },
      ],
    },
    {
      title: "Company",
      links: [
        { name: "About Us", path: "/" },
        { name: "Careers", path: "/" },
        { name: "Blog", path: "/" },
        { name: "Contact", path: "/" },
      ],
    },
    {
      title: "Resources",
      links: [
        { name: "Help Center", path: "/" },
        { name: "Documentation", path: "/" },
        { name: "API", path: "/" },
        { name: "Partners", path: "/" },
      ],
    },
    {
      title: "Legal",
      links: [
        { name: "Privacy Policy", path: "/" },
        { name: "Terms of Service", path: "/" },
        { name: "Cookie Policy", path: "/" },
        { name: "GDPR", path: "/" },
      ],
    },
  ];

  return (
    <footer className="bg-navy text-navy-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-8">
          <div className="col-span-2 md:col-span-4 lg:col-span-1">
            <Link to="/" className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent inline-block mb-4">
              TalentsHub
            </Link>
            <p className="text-sm text-navy-foreground/80">
              Empowering the future workforce by connecting top global talent with leading companies.
            </p>
          </div>

          {footerSections.map((section) => (
            <div key={section.title}>
              <h3 className="font-semibold mb-4">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.path}
                      className="text-sm text-navy-foreground/70 hover:text-navy-foreground transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-navy-foreground/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-navy-foreground/70">
              © {new Date().getFullYear()} TalentsHub. All rights reserved.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-navy-foreground/70 hover:text-navy-foreground transition-colors">
                LinkedIn
              </a>
              <a href="#" className="text-navy-foreground/70 hover:text-navy-foreground transition-colors">
                Twitter
              </a>
              <a href="#" className="text-navy-foreground/70 hover:text-navy-foreground transition-colors">
                Facebook
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
