import { Link, useLocation } from "react-router-dom";
import DashboardNavbar from "./DashboardNavbar";
import { Home, Briefcase, FileText, User, MessageSquare } from "lucide-react";

interface TalentLayoutProps {
  children: React.ReactNode;
}

const TalentLayout = ({ children }: TalentLayoutProps) => {
  const location = useLocation();
  
  const menuItems = [
    { label: "Overview", icon: Home, path: "/talent/overview" },
    { label: "Jobs", icon: Briefcase, path: "/talent/jobs" },
    { label: "Applications", icon: FileText, path: "/talent/applications" },
    { label: "Profile", icon: User, path: "/talent/profile" },
    { label: "Messages", icon: MessageSquare, path: "/talent/messages" },
  ];

  return (
    <div className="min-h-screen flex w-full">
      <aside className="w-64 border-r bg-card">
        <div className="p-6 border-b">
          <h2 className="text-lg font-bold">TalentsHub Talent</h2>
        </div>
        <nav className="p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-accent"
                }`}
              >
                <Icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </aside>
      
      <div className="flex-1 flex flex-col">
        <DashboardNavbar title="TalentsHub Talent" />
        <main className="flex-1 p-6 bg-background">
          {children}
        </main>
      </div>
    </div>
  );
};

export default TalentLayout;
